# Task 1 requirement mapping

| Internship instruction | Where it is addressed |
|---|---|
| Use Python libraries like BeautifulSoup or Scrapy | `web_scraping.py` imports Requests and BeautifulSoup |
| Identify and collect relevant datasets from public web pages | The scraper collects book listing data from Books to Scrape |
| Use Octoparse or ParseHub if you do not code | This repository uses the coded Python option; no-code tools are alternatives |
| Handle HTML structure and web navigation | CSS selectors parse HTML; the `Next` link is followed for pagination |
| Create custom datasets for analysis | Outputs `data/books_dataset.csv` with title, price, availability, rating, and URLs |
