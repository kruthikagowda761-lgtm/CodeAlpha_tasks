import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def main():
    # Sample monthly business dataset
    data = {
        "Month": [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ],
        "Sales": [
            12000, 15000, 13500, 18000, 22000, 20000,
            25000, 28000, 24000, 30000, 35000, 40000
        ],
        "Profit": [
            2000, 3000, 2500, 4000, 5000, 4500,
            6000, 7000, 5500, 8000, 9000, 11000
        ],
        "Customers": [
            120, 150, 135, 180, 220, 200,
            250, 280, 240, 300, 350, 400
        ]
    }

    df = pd.DataFrame(data)

    print("\\nDATASET")
    print(df.to_string(index=False))
    print("\\nDATA SUMMARY")
    print(df.describe())
    print(f"\\nTotal sales: ₹{df['Sales'].sum():,}")
    print(f"Total profit: ₹{df['Profit'].sum():,}")
    print(f"Total customers across months: {df['Customers'].sum():,}")
    print(f"Best sales month: {df.loc[df['Sales'].idxmax(), 'Month']}")

    sns.set_theme(style="whitegrid")
    fig, axes = plt.subplots(2, 2, figsize=(14, 9))

    sns.barplot(data=df, x="Month", y="Sales", ax=axes[0, 0])
    axes[0, 0].set_title("Monthly Sales")
    axes[0, 0].set_ylabel("Sales (₹)")
    axes[0, 0].set_xlabel("Month")

    axes[0, 1].plot(df["Month"], df["Sales"], marker="o", label="Sales")
    axes[0, 1].plot(df["Month"], df["Profit"], marker="s", label="Profit")
    axes[0, 1].set_title("Sales and Profit Trends")
    axes[0, 1].set_xlabel("Month")
    axes[0, 1].set_ylabel("Amount (₹)")
    axes[0, 1].legend()

    sns.lineplot(data=df, x="Month", y="Customers", marker="o", ax=axes[1, 0])
    axes[1, 0].set_title("Monthly Customer Growth")
    axes[1, 0].set_xlabel("Month")
    axes[1, 0].set_ylabel("Number of Customers")

    sns.scatterplot(
        data=df, x="Sales", y="Profit", size="Customers",
        sizes=(50, 300), ax=axes[1, 1], legend=True
    )
    axes[1, 1].set_title("Sales vs Profit")
    axes[1, 1].set_xlabel("Sales (₹)")
    axes[1, 1].set_ylabel("Profit (₹)")

    fig.suptitle(
        "BUSINESS SALES DATA VISUALIZATION DASHBOARD",
        fontsize=16, fontweight="bold"
    )
    plt.tight_layout()
    plt.savefig("data_visualization_dashboard.png", dpi=300, bbox_inches="tight")
    plt.show()

    df.to_csv("sales_data.csv", index=False)
    print("\\nSaved: data_visualization_dashboard.png")
    print("Saved: sales_data.csv")
    print("TASK 3 COMPLETED SUCCESSFULLY!")


if __name__ == "__main__":
    main()
