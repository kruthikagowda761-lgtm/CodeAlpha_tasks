# Task 3: Data Visualization

A beginner-friendly Python project that uses Pandas, Matplotlib, and Seaborn to summarize sample monthly sales data and create a four-chart dashboard.

## Requirements
- Python 3.9 or newer
- Internet connection for the first-time library installation

## Run on Windows / Git Bash / macOS / Linux

1. Extract the ZIP file.
2. Open a terminal in the `DataVisualization` folder.
3. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Run the program:

   ```bash
   python data_visualization.py
   ```

   If `python` is not recognized on Windows, try `py` instead:

   ```bash
   py -m pip install -r requirements.txt
   py data_visualization.py
   ```

## Output
The script creates:
- `data_visualization_dashboard.png` — a high-resolution dashboard image
- `sales_data.csv` — the sample dataset used for the charts

The project uses illustrative sample data. Replace the data dictionary in `data_visualization.py` with your own data for a real analysis.
