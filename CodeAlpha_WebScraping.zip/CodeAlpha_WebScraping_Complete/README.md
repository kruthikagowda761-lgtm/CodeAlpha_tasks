# CodeAlpha Internship — Task 1: Web Scraping

## Project overview
This project demonstrates web scraping with Python, Requests, and BeautifulSoup using **Books to Scrape**, a practice website intended for scraping exercises.

It follows the website's pagination and collects book listing information into a reusable CSV dataset.

## How this project covers the task requirements

1. **Python libraries (BeautifulSoup):** Requests downloads pages and BeautifulSoup parses their HTML.
2. **Relevant public webpage data:** Collects book title, price, availability, star rating, detail-page URL, and listing-page URL.
3. **Automated tools option:** This is the coded Python approach. Octoparse or ParseHub are alternative no-code options, not required to run this project.
4. **HTML structure and web navigation:** Uses CSS selectors such as `article.product_pod`, `.price_color`, `.availability`, and `li.next a`. The scraper follows the `Next` link to navigate through multiple listing pages.
5. **Custom dataset:** Saves the collected fields in `data/books_dataset.csv`, suitable for later price, rating, and availability analysis.

## Requirements
- Python 3.9+
- Internet connection

## Run on Windows (VS Code)
1. Download and extract the ZIP.
2. In VS Code, choose **File → Open Folder** and open the extracted `CodeAlpha_WebScraping_Complete` folder.
3. Open **Terminal → New Terminal**. Confirm the terminal is in the folder containing `web_scraping.py`.
4. Install the libraries:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Run the scraper:

   ```powershell
   python web_scraping.py
   ```

6. When finished, open `data/books_dataset.csv`.

If you get “can't open file”, type `dir` and check that `web_scraping.py` is listed. If not, use **File → Open Folder** to open the folder that contains the script.

## Output columns
- `title`: Book title
- `price`: Displayed price as text
- `availability`: Availability text
- `rating`: Star-rating label
- `detail_url`: Link to the book detail page
- `listing_page`: Page from which the book was collected

## Responsible scraping
- Use the practice website for learning.
- Keep requests limited and spaced out.
- Only scrape pages you are permitted to access; respect website terms and access restrictions.
- This example visits at most 50 listing pages.

## Submission checklist
- [ ] Run the script successfully.
- [ ] Check `data/books_dataset.csv` and confirm it contains rows.
- [ ] Keep `web_scraping.py`, `requirements.txt`, and `README.md` in your repository.
- [ ] Include the generated CSV in your submission if your internship instructions request the dataset.
- [ ] Follow CodeAlpha's required GitHub repository naming, LinkedIn post, and submission-form instructions.

## Note
The CSV is generated when you run the script, so it is not pre-filled with scraped live website data in this ZIP.
