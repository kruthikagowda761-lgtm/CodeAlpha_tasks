"""
CodeAlpha Internship — Task 1: Web Scraping
Scrapes the Books to Scrape practice website using Requests and BeautifulSoup.
Follows pagination, parses HTML fields, and exports a custom dataset to CSV.
"""

from pathlib import Path
import time
import requests
import pandas as pd
from bs4 import BeautifulSoup
from urllib.parse import urljoin

BASE_URL = "https://books.toscrape.com/"
OUTPUT_DIR = Path(__file__).resolve().parent / "data"
OUTPUT_FILE = OUTPUT_DIR / "books_dataset.csv"
MAX_PAGES = 50  # The practice site has multiple pages; limit requests politely.

HEADERS = {
    "User-Agent": "CodeAlphaEducationalWebScraper/1.0 (learning project)"
}


def scrape_book_page(session, page_url):
    """Fetch and parse one listing page using its HTML structure."""
    response = session.get(page_url, headers=HEADERS, timeout=20)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")

    rows = []
    for item in soup.select("article.product_pod"):
        title_link = item.select_one("h3 a")
        price_tag = item.select_one(".price_color")
        availability_tag = item.select_one(".availability")
        rating_tag = item.select_one("p.star-rating")

        if not (title_link and price_tag and availability_tag):
            continue

        rating_classes = rating_tag.get("class", []) if rating_tag else []
        rating = next((value for value in rating_classes
                       if value in {"One", "Two", "Three", "Four", "Five"}), "Unknown")

        detail_href = title_link.get("href", "")
        rows.append({
            "title": title_link.get("title", title_link.get_text(strip=True)),
            "price": price_tag.get_text(strip=True),
            "availability": availability_tag.get_text(" ", strip=True),
            "rating": rating,
            "detail_url": urljoin(page_url, detail_href),
            "listing_page": page_url,
        })

    next_link = soup.select_one("li.next a")
    next_url = urljoin(page_url, next_link.get("href")) if next_link else None
    return rows, next_url


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    all_books = []
    page_url = BASE_URL
    page_count = 0

    with requests.Session() as session:
        while page_url and page_count < MAX_PAGES:
            page_count += 1
            print(f"Scraping page {page_count}: {page_url}")
            page_rows, next_url = scrape_book_page(session, page_url)
            all_books.extend(page_rows)
            page_url = next_url
            # Be considerate when visiting multiple pages.
            if page_url:
                time.sleep(0.3)

    if not all_books:
        print("No books were scraped. Check your internet connection and try again.")
        return

    df = pd.DataFrame(all_books)
    df = df.drop_duplicates(subset=["title"]).reset_index(drop=True)
    df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

    print("\\nScraping completed successfully.")
    print(f"Pages visited: {page_count}")
    print(f"Unique books collected: {len(df)}")
    print(f"CSV saved to: {OUTPUT_FILE}")
    print("\\nPreview:")
    print(df.head(10).to_string(index=False))


if __name__ == "__main__":
    main()
